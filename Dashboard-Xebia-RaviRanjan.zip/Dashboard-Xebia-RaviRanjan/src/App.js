import React from 'react';
import DashBoard from './component/DashBoard';
import Headers from './component/Header';
function App() {
  return (
    <div className="App">
      <Headers />
       <DashBoard/> 
    </div>
  );
}

export default App;
