import React, { Component } from 'react';
import Content1 from './Content1';
import Content2 from './Content2';
import Content3 from './Content3';
import Content4 from './Content4';

class DashBoard extends Component {

    render() {
        return (
            <>
                <div className="main-container">
                    <Content1 />
                    <Content2 />
                    <Content3 />
                    <Content4 />
                </div>

            </>
        );
    }
}

export default DashBoard;
