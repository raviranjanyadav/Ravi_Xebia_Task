import React, { Component } from 'react';
import MapChart from "./MapChart";
import './style.css';
class Content3 extends Component {
    render() {
        return (
            <>
            <div>
             
                <h1>Description : {"World Map"}</h1>
                <MapChart />
            </div>
            </>
        );
    }
}

export default Content3;
