# Analytics Dashboard

steps to follow:

1) npm install @material-ui/core
2) npm install react-apexcharts apexcharts
3) npm install react react-dom react-simple-maps --save
4) npm i
